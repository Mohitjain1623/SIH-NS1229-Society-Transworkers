const firebaseConfig = {
    apiKey: "AIzaSyCsl--R_ljPytPX8vfivAjXlUIBGUJneLA",
    authDomain: "sih-portal.firebaseapp.com",
    projectId: "sih-portal",
    storageBucket: "sih-portal.appspot.com",
    messagingSenderId: "718042279547",
    appId: "1:718042279547:web:cb8e50d8c4ce6b34d8fcde",
    measurementId: "G-TXZ4P95Z39"
  };